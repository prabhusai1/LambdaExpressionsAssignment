/*Write an application using lambda expressions to print Orders having 2 criteria implemented: 
 * 1) order price more than 10000 
 * 2) order status is ACCEPTED or COMPLETED.*/
package com.capgemini.LambdaAssignment.functionalinterface;

@FunctionalInterface
public interface OrderApplication {
	public void printOrder(long amount, String status);
}
