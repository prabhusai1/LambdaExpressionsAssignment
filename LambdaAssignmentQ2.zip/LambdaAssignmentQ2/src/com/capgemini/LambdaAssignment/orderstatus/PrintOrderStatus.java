package com.capgemini.LambdaAssignment.orderstatus;

import java.util.Scanner;

import com.capgemini.LambdaAssignment.functionalinterface.OrderApplication;

public class PrintOrderStatus {

	public static void main(String[] args) {
		long amount;
		String status;

		Scanner in = new Scanner(System.in);

		System.out.println("enter amount");
		amount = in.nextLong();

		System.out.println("enter status");
		status = in.next();

		OrderApplication order = (long amt, String stat) -> {
			if (amt > 10000) {
				if (stat.equalsIgnoreCase("ACCEPTED") || stat.equalsIgnoreCase("COMPLETED")) {
					System.out.println("order");
				}
			}
		};

		order.printOrder(amount, status);
		order.printOrder(25000, "Accepted");
		order.printOrder(2500, "Accepted");
		order.printOrder(25000, "Accept");

	}
}
