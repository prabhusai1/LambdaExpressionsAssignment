/* Use the functional interfaces Supplier, Consumer, Predicate & Function to invoke built-in methods from Java API */

package com.capgemini.lambdaassignments.invokebuiltinmethods;

import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class InvokeBuiltInMethods {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		Supplier<Integer> supplier = () -> new Integer((int) (Math.random() * 1000D));

		Consumer<Integer> consumer = (value) -> System.out.println(value);
		
		Predicate<T> predicate=()->{
			
		};
	}

}
