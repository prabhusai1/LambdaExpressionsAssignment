package com.capgemini.lambdaassignment;

import java.util.Scanner;

public class CalculateByImplementingCalculatorInterface {
	public static void main(String[] args) {
		CalculateByImplementingCalculatorInterface c = new CalculateByImplementingCalculatorInterface();
		c.addMethod();

		System.out.println("Done with addition \n");
		c.subtractMethod();

		System.out.println("Done with subtraction \n");
		c.multiplyMethod();

		System.out.println("Done with multiplication \n");
		c.divideMethod();
		
		System.out.println("Done with division \n");
	}

	public void addMethod() {
		Scanner in = new Scanner(System.in);
		Calculator addCalc = (long x, long y) -> {
			long z = x + y;
			return z;
		};

		System.out.println("enter x value");
		long x = in.nextLong();

		System.out.println("enter y value");
		long y = in.nextLong();

		long addResult = addCalc.calculate(x, y);
		System.out.println("result for addition is " + addResult);
	}

	public void subtractMethod() {
		Scanner in = new Scanner(System.in);
		Calculator subtractCalc = (long x, long y) -> {
			long z = x - y;
			return z;
		};

		System.out.println("enter x value");
		long x = in.nextLong();

		System.out.println("enter y value");
		long y = in.nextLong();

		long subtractResult = subtractCalc.calculate(x, y);
		System.out.println("result for subtrcation is " + subtractResult);
	}

	public void multiplyMethod() {
		Scanner in = new Scanner(System.in);
		Calculator multiCalc = (long x, long y) -> {
			long z = x * y;
			return z;
		};

		System.out.println("enter x value");
		long x = in.nextLong();

		System.out.println("enter y value");
		long y = in.nextLong();

		long multiResult = multiCalc.calculate(x, y);
		System.out.println("result for multiplication is " + multiResult);
	}

	public void divideMethod() {
		Scanner in = new Scanner(System.in);
		Calculator divideCalc = (long x, long y) -> {
			long z = x / y;
			return z;
		};

		System.out.println("enter x value");
		long x = in.nextLong();

		System.out.println("enter y value");
		long y = in.nextLong();

		long divideResult = divideCalc.calculate(x, y);
		System.out.println("result for division is " + divideResult);
	}

}
