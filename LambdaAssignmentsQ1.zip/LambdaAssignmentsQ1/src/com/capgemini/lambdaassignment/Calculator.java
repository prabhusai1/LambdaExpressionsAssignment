package com.capgemini.lambdaassignment;

@FunctionalInterface
public interface Calculator {
	public long calculate(long x, long y);
}
